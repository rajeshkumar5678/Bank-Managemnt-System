package test2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
public class banking{
public static void main(String args[]){
try{
Class.forName("oracle.jdbc.driver.OracleDriver");

Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/orcl.iiht.tech","scott","tiger");

Statement stmt=con.createStatement(); 

ResultSet rs=stmt.executeQuery("select * from bank");
String bl="";
while(rs.next())
	
	 bl=rs.getString(3);
String query1 =  "INSERT INTO bank (Account_Name, ACCOUNTNUMBER, TOTALBALANCE)"
		 + "VALUES ('Amaan', 2345, 6100 )";
int count = stmt.executeUpdate(query1);
System.out.println("Number of rows updated in database =  " + count);

float w=299100;
float ubl=Float.parseFloat(bl)-w;
Statement stt=con.createStatement();
stt.executeQuery("update bank set TOTALBALANCE='"+ubl+"' where ACCOUNT_NAME='Rajesh'");
System.out.println(ubl);

}catch(Exception e){
	System.out.println(e);}


}
}