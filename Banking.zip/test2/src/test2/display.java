package test2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;  
class BankDetails {  
    private String accno;  
    private String name;  
    private String acc_type;  
    private long balance;  
    Scanner sc = new Scanner(System.in);  
    //method to open new account  
    public void openAccount() {  
        System.out.print("Enter Account No: ");  
        accno = sc.next();  
        System.out.print("Enter Account type: ");  
        acc_type = sc.next();  
        System.out.print("Enter Name: ");  
        name = sc.next();  
        System.out.print("Enter Balance: ");  
        balance = sc.nextLong();  
    }  
    //method to display account details  
    public void showAccount() {  
        System.out.println("Name of account holder: " + name);  
        System.out.println("Account no.: " + accno);  
        System.out.println("Account type: " + acc_type);  
        System.out.println("Balance: " + balance);  
    }  
    //method to deposit money  
    public void deposit() {  
        long amt;  
        System.out.println("Enter the amount you want to deposit: ");  
        amt = sc.nextLong();  
        balance = balance + amt; 
        
    }  
    //method to withdraw money  
    public void withdrawal() { 
    	Scanner sc5=new Scanner(System.in);
    	String Accountno;
    	System.out.println("Enter the Account number");
    	
        long amt;  
        System.out.println("Enter the amount you want to withdraw: ");  
        amt = sc.nextLong();  
        if (balance >= amt) {  
            balance = balance - amt;  
            System.out.println("Balance after withdrawal: " + balance);  
        } else {  
            System.out.println("Your balance is less than " + amt + "\tTransaction failed...!!" );  
        }  
        
    }  
    //method to search an account number  
    public boolean search(String ac_no) {  
        if (accno.equals(ac_no)) {  
            showAccount();  
            return (true);  
        }  
        return (false);  
    }  
}  
public class display {  
    public static void main(String arg[]) {  
        Scanner sc = new Scanner(System.in);  
        //create initial accounts  
        System.out.print("How many number of customers do you want to input? ");  
        int n = sc.nextInt();  
        BankDetails C[] = new BankDetails[n];  
        for (int i = 0; i < C.length; i++) {  
            C[i] = new BankDetails();  
            C[i].openAccount();  
        }  
        // loop runs until number 5 is not pressed to exit 
        
        int ch;  
        do {  
            System.out.println("\n ***Banking System Application***");  
            System.out.println("1. Display all account details \n 2. Search by Account number\n 3. Deposit the amount \n 4. Withdraw the amount \n 5.Exit ");  
            System.out.println("Enter your choice: ");  
            ch = sc.nextInt(); 
            try{
            	Class.forName("oracle.jdbc.driver.OracleDriver");

            	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/orcl.iiht.tech","scott","tiger");

            	Statement stmt=con.createStatement(); 

            
                switch (ch) {  
                    case 1:  
                        for (int i = 0; i < C.length; i++) {  
                            C[i].showAccount();  
                            Scanner sc1=new Scanner(System.in);
                           
                            
                           String s1;
                            int s2;
                           int s3;
                            System.out.println("Enter the  name");
                            s1=sc1.nextLine();
                            System.out.println("Enter the account number");
                          s2=sc1.nextInt();
                          System.out.println("Enter the Total balance");
                          s3=sc1.nextInt();
                            
                            String query1 =  "INSERT INTO bank (Account_Name, ACCOUNTNUMBER, TOTALBALANCE)"
                           		 + "VALUES ('"+s1+"', "+s2+", "+s3+" )";
                           int count = stmt.executeUpdate(query1);
                        }  
                        break;  
                    case 2:  
                        System.out.print("Enter account no. you want to search: ");  
                        String ac_no = sc.next();  
                        boolean found = false;  
                        for (int i = 0; i < C.length; i++) {  
                            found = C[i].search(ac_no); 
                            stmt.executeQuery("");
                            if (found) {  
                                break;  
                            }  
                        }  
                        if (!found) {  
                            System.out.println("Search failed! Account doesn't exist..!!");  
                        }  
                        break;  
                    case 3: 
                    	Statement st3=con.createStatement(); 
                    	Scanner sc6=new Scanner(System.in);
                    	String Account_no;
                    	System.out.println("Enter the Account number");
                    	Account_no=sc6.nextLine();
                        long amd,bl=0;  
                        System.out.println("Enter the amount you want to Deposit: ");  
                        amd = sc.nextLong();  
                     ResultSet rs2=st3.executeQuery("Select TOTALBALANCE FROM bank where ACCOUNTNUMBER='"+Account_no+"'");
                     
                     while(rs2.next())
                     {
                    	bl=Long.parseLong(rs2.getString(1));
                     }
                     Statement st9=con.createStatement(); 
                     Long ub=bl+amd;
                     
                     st9.executeQuery("Update bank Set TOTALBALANCE='"+ub+"'where ACCOUNTNUMBER='"+Account_no+"'");
                        
                         // int count = st.executeUpdate(query2);
                         System.out.println("Deposit Successful Current balance="+ub);
                       // if (balance >= amt) {  
                            //balance = balance - amt;  
                           // System.out.println("Balance after withdrawal: " + balance);  
                      //  } else {  
                          //  System.out.println("Your balance is less than " + amt + "\tTransaction failed...!!" );  
                        //}  
                        
                    //}  
                       
                            
                
                        break;  
                    case 4:  
                    	Statement st=con.createStatement(); 
                    	Scanner sc5=new Scanner(System.in);
                    	String Accountno;
                    	System.out.println("Enter the Account number");
                    	Accountno=sc5.nextLine();
                        long amt,balance=0;  
                        System.out.println("Enter the amount you want to withdraw: ");  
                        amt = sc.nextLong();  
                     ResultSet rs1=st.executeQuery("Select TOTALBALANCE FROM bank where ACCOUNTNUMBER='"+Accountno+"'");
                     
                     while(rs1.next())
                     {
                    	balance=Long.parseLong(rs1.getString(1));
                     }
                     Statement st1=con.createStatement(); 
                     Long ulb=balance-amt;
                     
                     st1.executeQuery("Update bank Set TOTALBALANCE='"+ulb+"'where ACCOUNTNUMBER='"+Accountno+"'");
                        
                         // int count = st.executeUpdate(query2);
                         System.out.println("Withdraw Successful Current balance="+ulb);
                       // if (balance >= amt) {  
                            //balance = balance - amt;  
                           // System.out.println("Balance after withdrawal: " + balance);  
                      //  } else {  
                          //  System.out.println("Your balance is less than " + amt + "\tTransaction failed...!!" );  
                        //}  
                        
                    //}  
                    	

                       break; 
                    case 5:  
                        System.out.println("See you soon...");  
                        break; 
                        
                } 
           con.close(); }
            
            catch(Exception e) 
            {
            	System.out.println(e);
            }
            }
        
            while (ch != 5);  
        
    
    }
}